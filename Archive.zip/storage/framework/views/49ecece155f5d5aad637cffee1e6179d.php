<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Hero Section -->
    <?php $__currentLoopData = $heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($heroSection->is_active): ?>
            <div class="bg-primary text-white py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <h1 class="display-4 fw-bold mb-3"><?php echo e($heroSection->title); ?></h1>
                            <p class="lead mb-4"><?php echo e($heroSection->description); ?></p>
                            <a href="<?php echo e($heroSection->button_link); ?>" class="btn btn-light btn-lg"><?php echo e($heroSection->button_text); ?></a>
                        </div>
                        <div class="col-lg-6">
                            <img src="<?php echo e($heroSection->image_url); ?>" alt="Hero" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <!-- Categories Section -->
    <div class="py-5 bg-light">
        <div class="container">
            <div class="row mb-4">
                <div class="col-lg-6 mx-auto text-center">
                    <h2 class="mb-3">تصفح حسب التصنيف</h2>
                    <p class="text-muted">اكتشف مجموعة متنوعة من التصنيفات التعليمية المتخصصة</p>
                </div>
            </div>
            <div class="row g-4">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3">
                        <a href="<?php echo e(route('categories.show', $category)); ?>" class="text-decoration-none">
                            <div class="card h-100 border-0 shadow-sm hover-shadow transition">
                                <div class="card-body text-center p-4">
                                    <div class="icon-box mb-3">
                                        <i class="fas fa-<?php echo e($category->icon ?? 'book'); ?> fa-2x text-primary"></i>
                                    </div>
                                    <h5 class="card-title text-dark mb-2"><?php echo e($category->name); ?></h5>
                                    <p class="card-text text-muted small mb-2"><?php echo e(Str::limit($category->description, 80)); ?></p>
                                    <div class="mt-3">
                                        <span class="badge bg-primary"><?php echo e($category->courses_count); ?> دورة</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-5">
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-primary">
                    عرض جميع التصنيفات
                    <i class="fas fa-arrow-left me-2"></i>
                </a>
            </div>
        </div>
    </div>


    <!-- Featured Courses -->
    <div class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">الدورات المميزة</h2>
            <div class="row g-4">
                <?php $__currentLoopData = $latestCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 border-0 shadow-sm">
                            <img src="<?php echo e($course->image_url); ?>" 
                                 class="card-img-top"
                                 style="height: 200px; object-fit: cover;"
                                 alt="<?php echo e($course->title); ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-primary"><?php echo e($course->category->name); ?></span>
                                    <span class="text-primary fw-bold"><?php echo e($course->price); ?> ج.م</span>
                                </div>
                                <h5 class="card-title">
                                    <a href="<?php echo e(route('courses.show', $course)); ?>" class="text-decoration-none text-dark">
                                        <?php echo e($course->title); ?>

                                    </a>
                                </h5>
                                <p class="card-text text-muted"><?php echo e(Str::limit($course->description, 100)); ?></p>
                            </div>
                            <div class="card-footer bg-white border-top-0">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo e($course->instructor->profile_photo_url); ?>" 
                                                 class="rounded-circle me-2" 
                                                 width="30" 
                                                 alt="<?php echo e($course->instructor->name); ?>">
                                            <small class="text-muted"><?php echo e($course->instructor->name); ?></small>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="d-flex align-items-center text-muted small">
                                            <span class="me-3">
                                                <i class="fas fa-book-reader me-1"></i>
                                                <?php echo e($course->lectures_count); ?> درس
                                            </span>
                                            <span>
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo e($course->duration_in_weeks); ?> أسابيع
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-5">
                <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary btn-lg">عرض جميع الدورات</a>
            </div>
        </div>
    </div>

    <!-- Featured Instructors -->
    <div class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-5">نخبة من المدربين</h2>
            <div class="row g-4">
                <?php $__currentLoopData = $featuredInstructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shadow-sm text-center">
                            <div class="card-body">
                                <img src="<?php echo e($instructor->profile_photo_url); ?>" 
                                     class="rounded-circle mb-3" 
                                     width="120" 
                                     height="120"
                                     alt="<?php echo e($instructor->name); ?>">
                                <h5 class="card-title"><?php echo e($instructor->name); ?></h5>
                                <p class="text-primary mb-2"><?php echo e($instructor->title); ?></p>
                                <p class="text-muted small mb-3"><?php echo e(Str::limit($instructor->bio, 100)); ?></p>
                                <a href="<?php echo e(route('instructors.show', $instructor)); ?>" 
                                   class="btn btn-outline-primary">
                                    عرض الملف الشخصي
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-5">
                <a href="<?php echo e(route('instructors.index')); ?>" class="btn btn-primary btn-lg">عرض جميع المدربين</a>
            </div>
        </div>
    </div>

    <!-- Features -->
    <div class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="text-center">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h4>دورات عالية الجودة</h4>
                        <p class="text-muted">تعلم من نخبة من المدربين المحترفين في مجالاتهم</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h4>تعلم في أي وقت</h4>
                        <p class="text-muted">ادرس بالسرعة التي تناسبك وفي الوقت المناسب لك</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center">
                        <div class="display-4 text-primary mb-3">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h4>شهادات معتمدة</h4>
                        <p class="text-muted">احصل على شهادات معتمدة تؤهلك لسوق العمل</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA -->
    <div class="bg-primary text-white py-5">
        <div class="container text-center">
            <h2 class="mb-4">ابدأ رحلة التعلم اليوم</h2>
            <p class="lead mb-4">سجل الآن واحصل على خصم 20% على جميع الدورات</p>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-light btn-lg">سجل الآن</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/Archive/resources/views/welcome.blade.php ENDPATH**/ ?>