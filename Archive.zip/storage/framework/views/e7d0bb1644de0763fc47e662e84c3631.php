<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Course Header -->
    <div class="bg-primary text-white py-5">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none">
                                    <i class="fas fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('courses.index')); ?>" class="text-white text-decoration-none">الدورات</a>
                            </li>
                            <li class="breadcrumb-item active text-white" aria-current="page">
                                <?php echo e($course->title); ?>

                            </li>
                        </ol>
                    </nav>
                    <h1 class="display-4 fw-bold mb-3"><?php echo e($course->title); ?></h1>
                    <p class="lead mb-4"><?php echo e($course->description); ?></p>
                    <div class="d-flex flex-wrap gap-4 mb-4">
                        <div>
                            <i class="fas fa-clock me-2"></i>
                            <?php echo e($course->duration); ?> ساعة
                        </div>
                        <div>
                            <i class="fas fa-book me-2"></i>
                            <?php echo e($course->lessons->count()); ?> درس
                        </div>
                        <div>
                            <i class="fas fa-signal me-2"></i>
                            <?php echo e($course->level); ?>

                        </div>
                        <div>
                            <i class="fas fa-language me-2"></i>
                            <?php echo e($course->language); ?>

                        </div>
                    </div>
                    <div class="d-flex gap-3">
                        <?php if(auth()->guard()->check()): ?>
                            <?php
                                $enrollment = $course->enrollment;
                            ?>

                            <?php if(!$enrollment): ?>
                                <form action="<?php echo e(route('courses.enroll', $course)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-light btn-lg">
                                        <i class="fas fa-graduation-cap me-2"></i>
                                        التسجيل في الدورة
                                    </button>
                                </form>
                            <?php elseif($enrollment->status === 'approved'): ?>
                                <a href="<?php echo e(route('courses.learn', $course)); ?>" class="btn btn-success btn-lg">
                                    <i class="fas fa-play-circle me-2"></i>
                                    متابعة التعلم
                                </a>
                            <?php elseif($enrollment->status === 'pending'): ?>
                                <button class="btn btn-warning btn-lg" disabled>
                                    <i class="fas fa-clock me-2"></i>
                                    في انتظار الموافقة
                                </button>
                            <?php else: ?>
                                <button class="btn btn-danger btn-lg" disabled>
                                    <i class="fas fa-times-circle me-2"></i>
                                    تم رفض التسجيل
                                </button>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-light btn-lg">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                سجل دخول للتسجيل في الدورة
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-lg">
                        <div class="card-body p-4">
                            <div class="text-center mb-4">
                                <h3 class="text-primary mb-0"><?php echo e($course->price); ?> ج.م</h3>
                            </div>
                            <ul class="list-unstyled mb-4">
                                <li class="mb-3">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    إمكانية الوصول مدى الحياة
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    شهادة إتمام معتمدة
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    مشاريع عملية
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    دعم فني على مدار الساعة
                                </li>
                            </ul>
                            <?php if(auth()->guard()->check()): ?>
                                <?php
                                    $enrollment = $course->enrollment;
                                ?>

                                <?php if(!$enrollment): ?>
                                    <form action="<?php echo e(route('courses.enroll', $course)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary btn-lg w-100">
                                            <i class="fas fa-shopping-cart me-2"></i>
                                            اشترك الآن
                                        </button>
                                    </form>
                                <?php elseif($enrollment->status === 'approved'): ?>
                                    <a href="<?php echo e(route('courses.learn', $course)); ?>" class="btn btn-success btn-lg w-100">
                                        <i class="fas fa-play-circle me-2"></i>
                                        متابعة التعلم
                                    </a>
                                <?php elseif($enrollment->status === 'pending'): ?>
                                    <button class="btn btn-warning btn-lg w-100" disabled>
                                        <i class="fas fa-clock me-2"></i>
                                        في انتظار الموافقة
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-danger btn-lg w-100" disabled>
                                        <i class="fas fa-times-circle me-2"></i>
                                        تم رفض التسجيل
                                    </button>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-lg w-100">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    سجل دخول للاشتراك
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>








    <!-- Course Content -->
    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">


                    <!-- Promotional Video Section -->
    <?php if($course->promotional_video): ?>
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title mb-3">تعرف على الكورس
            </h5>
            <div class="ratio ratio-16x9">
                <iframe 
                    src="<?php echo e($course->promotional_video); ?>" 
                    title="فيديو ترويجي للدورة"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen>
                </iframe>
            </div>
        </div>
    </div>
<?php endif; ?>
                    <!-- Course Overview -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body">
                            <h3 class="card-title mb-4">نظرة عامة على الدورة</h3>
                            <div class="course-description">
                                <?php echo e($course->description); ?>

                            </div>
                        </div>
                    </div>


    



                    <!-- Course Lessons -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body">
                            <h3 class="card-title mb-4">محتوى الدورة</h3>
                            <div class="list-group list-group-flush">
                                <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                        <div>
                                            <i class="fas fa-play-circle text-primary me-2"></i>
                                            <?php echo e($lesson->title); ?>

                                        </div>
                                        <span class="text-muted small">
                                            <?php echo e($lesson->duration); ?> دقيقة
                                        </span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Instructor Info -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h3 class="card-title mb-4">المدرسون</h3>
                            <?php $__currentLoopData = $course->instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex mb-4">
                                    <img src="<?php echo e($instructor->profile_photo_url); ?>" 
                                         class="rounded-circle me-3" 
                                         width="64" 
                                         height="64"
                                         alt="<?php echo e($instructor->name); ?>">
                                    <div>
                                        <h5 class="mb-1"><?php echo e($instructor->name); ?></h5>
                                        <p class="text-muted mb-2"><?php echo e($instructor->title); ?></p>
                                        <p class="mb-0"><?php echo e($instructor->bio); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <!-- Share Course -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body">
                            <h5 class="card-title mb-3">شارك الدورة</h5>
                            <div class="d-flex gap-2">
                                <a href="#" class="btn btn-outline-primary flex-grow-1">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="btn btn-outline-info flex-grow-1">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="btn btn-outline-success flex-grow-1">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Related Courses -->
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-3">دورات ذات صلة</h5>
                            <?php $__currentLoopData = $course->category->courses->where('id', '!=', $course->id)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-3">
                                    <div class="row g-0">
                                        <div class="col-4">
                                            <img src="<?php echo e(Storage::url($relatedCourse->image)); ?>" 
                                                 class="img-fluid rounded-start h-100" 
                                                 style="object-fit: cover;"
                                                 alt="<?php echo e($relatedCourse->title); ?>">
                                        </div>
                                        <div class="col-8">
                                            <div class="card-body">
                                                <h6 class="card-title">
                                                    <a href="<?php echo e(route('courses.show', $relatedCourse)); ?>" 
                                                       class="text-decoration-none text-dark">
                                                        <?php echo e($relatedCourse->title); ?>

                                                    </a>
                                                </h6>
                                                <p class="card-text">
                                                    <small class="text-muted">
                                                        <?php echo e($relatedCourse->price); ?> ج.م
                                                    </small>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/my-laravel-app/resources/views/courses/show.blade.php ENDPATH**/ ?>