<?php if($paginator->hasPages()): ?>
    <nav dir="rtl" aria-label="صفحات التنقل">
        <ul class="pagination justify-content-center align-items-center my-3">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span class="page-link rounded-circle mx-1" aria-hidden="true">
                        <i class="fas fa-chevron-right"></i>
                    </span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link rounded-circle mx-1 hover-primary" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled" aria-disabled="true">
                        <span class="page-link"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active" aria-current="page">
                                <span class="page-link bg-primary border-primary rounded-circle mx-1"><?php echo e($page); ?></span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link text-dark rounded-circle mx-1 hover-primary" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link rounded-circle mx-1 hover-primary" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link rounded-circle mx-1" aria-hidden="true">
                        <i class="fas fa-chevron-left"></i>
                    </span>
                </li>
            <?php endif; ?>
        </ul>

        <div class="d-flex justify-content-center align-items-center mt-2">
            <p class="text-muted small mb-0">
                <?php echo __('Showing'); ?>

                <span class="fw-bold"><?php echo e($paginator->firstItem()); ?></span>
                <?php echo __('to'); ?>

                <span class="fw-bold"><?php echo e($paginator->lastItem()); ?></span>
                <?php echo __('of'); ?>

                <span class="fw-bold"><?php echo e($paginator->total()); ?></span>
                <?php echo __('results'); ?>

            </p>
        </div>
    </nav>

    <style>
        .page-link {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            transition: all 0.2s ease;
        }
        .page-link:hover {
            background-color: var(--bs-primary);
            color: white !important;
        }
        .hover-primary:hover {
            background-color: var(--bs-primary) !important;
            color: white !important;
        }
    </style>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/Archive/resources/views/vendor/pagination/bootstrap-5-rtl.blade.php ENDPATH**/ ?>