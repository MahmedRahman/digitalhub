<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="d-flex align-items-center mb-4">
                    <a href="<?php echo e(route('admin.hero-sections.create')); ?>" class="btn btn-primary me-3">
                        <i class="fas fa-plus me-2"></i>إضافة بانر جديد
                    </a>
                    <h2 class="fw-bold mb-0">إدارة البانر الرئيسي</h2>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <?php if($heroSections->isEmpty()): ?>
                            <div class="text-center py-5">
                                <div class="mb-3">
                                    <i class="fas fa-image fa-3x text-muted"></i>
                                </div>
                                <h4 class="text-muted">لا يوجد بانرات حالياً</h4>
                                <p class="text-muted mb-0">قم بإضافة بانر جديد من خلال الزر أعلاه</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th scope="col" style="width: 60px">#</th>
                                            <th scope="col">الصورة</th>
                                            <th scope="col">العنوان</th>
                                            <th scope="col">الوصف</th>
                                            <th scope="col">نص الزر</th>
                                            <th scope="col">الترتيب</th>
                                            <th scope="col">الحالة</th>
                                            <th scope="col" style="width: 200px">الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <img src="<?php echo e($heroSection->image_url); ?>" 
                                                         alt="Hero Image" 
                                                         class="rounded"
                                                         width="80">
                                                </td>
                                                <td><?php echo e($heroSection->title); ?></td>
                                                <td><?php echo e(Str::limit($heroSection->description, 50)); ?></td>
                                                <td><?php echo e($heroSection->button_text); ?></td>
                                                <td><?php echo e($heroSection->sort_order); ?></td>
                                                <td>
                                                    <?php if($heroSection->is_active): ?>
                                                        <span class="badge bg-success">نشط</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">غير نشط</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.hero-sections.edit', $heroSection)); ?>" 
                                                       class="btn btn-sm btn-primary me-2">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('admin.hero-sections.destroy', $heroSection)); ?>" 
                                                          method="POST"
                                                          class="d-inline-block">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" 
                                                                class="btn btn-sm btn-danger"
                                                                onclick="return confirm('هل أنت متأكد من حذف هذا البانر؟')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/Archive/resources/views/admin/hero-sections/index.blade.php ENDPATH**/ ?>