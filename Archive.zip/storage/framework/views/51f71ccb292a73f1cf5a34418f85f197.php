<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .pagination {
            gap: 5px;
        }
        .page-link {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }
        .page-link:hover {
            color: #fff;
            background-color: var(--bs-primary);
        }
        .page-item.active .page-link {
            color: #fff;
            background-color: var(--bs-primary);
        }
        .page-item.disabled .page-link {
            background-color: #e9ecef;
            color: #adb5bd;
        }
    </style>
    <!-- Header -->
    <div class="bg-primary text-white py-5">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4">استكشف الدورات</h1>
            <div class="row">
                <div class="col-md-8">
                    <form action="<?php echo e(route('courses.index')); ?>" method="GET" class="d-flex gap-2">
                        <input type="text" 
                               name="search" 
                               class="form-control form-control-lg" 
                               placeholder="ابحث عن دورة..."
                               value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-light btn-lg px-4">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <!-- Filters Sidebar -->
                <div class="col-lg-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title mb-4">تصفية النتائج</h5>
                            <form action="<?php echo e(route('courses.index')); ?>" method="GET">
                                <!-- Categories -->
                                <div class="mb-4">
                                    <h6 class="mb-3">الأقسام</h6>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check mb-2">
                                            <input type="checkbox" 
                                                   name="categories[]" 
                                                   value="<?php echo e($category->id); ?>"
                                                   class="form-check-input"
                                                   id="category<?php echo e($category->id); ?>"
                                                   <?php echo e(in_array($category->id, request('categories', [])) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="category<?php echo e($category->id); ?>">
                                                <?php echo e($category->name); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <!-- Level -->
                                <div class="mb-4">
                                    <h6 class="mb-3">المستوى</h6>
                                    <?php $__currentLoopData = ['مبتدئ', 'متوسط', 'متقدم']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check mb-2">
                                            <input type="checkbox" 
                                                   name="levels[]" 
                                                   value="<?php echo e($level); ?>"
                                                   class="form-check-input"
                                                   id="level<?php echo e($loop->index); ?>"
                                                   <?php echo e(in_array($level, request('levels', [])) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="level<?php echo e($loop->index); ?>">
                                                <?php echo e($level); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <!-- Price Range -->
                                <div class="mb-4">
                                    <h6 class="mb-3">السعر</h6>
                                    <div class="form-check mb-2">
                                        <input type="radio" 
                                               name="price" 
                                               value="free"
                                               class="form-check-input"
                                               id="priceFree"
                                               <?php echo e(request('price') === 'free' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="priceFree">
                                            مجاني
                                        </label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input type="radio" 
                                               name="price" 
                                               value="paid"
                                               class="form-check-input"
                                               id="pricePaid"
                                               <?php echo e(request('price') === 'paid' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="pricePaid">
                                            مدفوع
                                        </label>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary w-100">
                                    تطبيق الفلتر
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Courses Grid -->
                <div class="col-lg-9">
                    <!-- Sort Options -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h5 class="mb-0"><?php echo e($courses->total()); ?> دورة</h5>
                        </div>
                        <div class="d-flex align-items-center">
                            <label class="me-2">ترتيب حسب:</label>
                            <select class="form-select" onchange="window.location.href=this.value">
                                <option value="<?php echo e(request()->fullUrlWithQuery(['sort' => 'latest'])); ?>"
                                        <?php echo e(request('sort') === 'latest' ? 'selected' : ''); ?>>
                                    الأحدث
                                </option>
                                <option value="<?php echo e(request()->fullUrlWithQuery(['sort' => 'price_low'])); ?>"
                                        <?php echo e(request('sort') === 'price_low' ? 'selected' : ''); ?>>
                                    السعر: من الأقل للأعلى
                                </option>
                                <option value="<?php echo e(request()->fullUrlWithQuery(['sort' => 'price_high'])); ?>"
                                        <?php echo e(request('sort') === 'price_high' ? 'selected' : ''); ?>>
                                    السعر: من الأعلى للأقل
                                </option>
                            </select>
                        </div>
                    </div>

                    <!-- Courses -->
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card h-100 border-0 shadow-sm">
                                    <img src="<?php echo e(Storage::url($course->image)); ?>" 
                                         class="card-img-top"
                                         style="height: 200px; object-fit: cover;"
                                         alt="<?php echo e($course->title); ?>">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="badge bg-primary"><?php echo e($course->category->name); ?></span>
                                            <span class="text-primary fw-bold"><?php echo e($course->price); ?> ج.م</span>
                                        </div>
                                        <h5 class="card-title">
                                            <a href="<?php echo e(route('courses.show', $course)); ?>" class="text-decoration-none text-dark">
                                                <?php echo e($course->title); ?>

                                            </a>
                                        </h5>
                                        <p class="card-text text-muted"><?php echo e(Str::limit($course->description, 100)); ?></p>
                                    </div>
                                    <div class="card-footer bg-white border-top-0">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <div class="d-flex align-items-center">
                                                    <?php if($course->instructors->isNotEmpty()): ?>
                                                        <img src="<?php echo e($course->instructors->first()->profile_photo_url); ?>" 
                                                             class="rounded-circle me-2" 
                                                             width="30" 
                                                             height="30"
                                                             alt="<?php echo e($course->instructors->first()->name); ?>">
                                                        <span class="small text-muted">
                                                            <?php echo e($course->instructors->first()->name); ?>

                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <div class="d-flex align-items-center text-muted small">
                                                    <div class="me-3">
                                                        <i class="fas fa-clock me-1"></i>
                                                        <?php echo e($course->duration); ?> ساعة
                                                    </div>
                                                    <div>
                                                        <i class="fas fa-book me-1"></i>
                                                        <?php echo e($course->lessons->count()); ?> درس
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <div class="text-center py-5">
                                    <img src="<?php echo e(asset('images/no-results.svg')); ?>" 
                                         alt="No Results" 
                                         class="img-fluid mb-4" 
                                         style="max-width: 200px;">
                                    <h3>لم يتم العثور على دورات</h3>
                                    <p class="text-muted">جرب تغيير معايير البحث</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        <?php echo e($courses->withQueryString()->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/my-laravel-app/resources/views/courses/index.blade.php ENDPATH**/ ?>