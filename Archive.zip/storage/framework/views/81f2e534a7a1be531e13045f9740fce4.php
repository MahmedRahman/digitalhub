<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-5">
        <!-- Category Header -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="card border-0 bg-primary text-white shadow-lg">
                    <div class="card-body p-5">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-3">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('categories.index')); ?>" class="text-white-50">التصنيفات</a>
                                </li>
                                <li class="breadcrumb-item active text-white" aria-current="page">
                                    <?php echo e($category->name); ?>

                                </li>
                            </ol>
                        </nav>
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <h1 class="display-4 fw-bold mb-3"><?php echo e($category->name); ?></h1>
                                <p class="lead mb-4"><?php echo e($category->description); ?></p>
                                <div class="d-flex align-items-center gap-3">
                                    <span class="badge bg-white text-primary fs-6 px-3 py-2">
                                        <i class="fas fa-graduation-cap me-2"></i>
                                        <?php echo e($courses->total()); ?> دورة متاحة
                                    </span>
                                    <span class="badge bg-white text-primary fs-6 px-3 py-2">
                                        <i class="fas fa-users me-2"></i>
                                        <?php echo e($courses->sum('students_count')); ?> طالب مسجل
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-4 text-lg-end">
                                <i class="fas fa-<?php echo e($category->icon ?? 'folder'); ?> fa-5x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Courses Grid -->
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 border-0 shadow-sm hover-card">
                        <?php if($course->thumbnail): ?>
                            <img src="<?php echo e(asset('storage/' . $course->thumbnail)); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo e($course->title); ?>"
                                 style="height: 200px; object-fit: cover;">
                        <?php else: ?>
                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center" 
                                 style="height: 200px;">
                                <i class="fas fa-graduation-cap fa-3x text-muted"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-primary-subtle text-primary">
                                    <?php echo e($course->level); ?>

                                </span>
                                <span class="text-muted small">
                                    <i class="fas fa-users me-1"></i>
                                    <?php echo e($course->students_count); ?> طالب
                                </span>
                            </div>
                            <h3 class="h5 mb-3"><?php echo e($course->title); ?></h3>
                            <p class="text-muted small mb-3">
                                <?php echo e(Str::limit($course->description, 100)); ?>

                            </p>
                            <div class="d-flex align-items-center mb-3">
                                <?php if($course->instructor): ?>
                                    <img src="<?php echo e($course->instructor->profile_photo_url); ?>" 
                                         class="rounded-circle me-2" 
                                         width="30" 
                                         alt="<?php echo e($course->instructor->name); ?>">
                                    <span class="small text-muted">
                                        <?php echo e($course->instructor->name); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="small text-muted">
                                        <i class="fas fa-user-circle me-2"></i>
                                        مدرس غير محدد
                                    </span>
                                <?php endif; ?>
                            </div>
                            <hr class="my-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="<?php echo e(route('courses.show', $course)); ?>" 
                                   class="btn btn-outline-primary rounded-pill px-4">
                                    عرض التفاصيل
                                    <i class="fas fa-arrow-left ms-2"></i>
                                </a>
                                <?php if($course->price > 0): ?>
                                    <span class="text-primary fw-bold">
                                        <?php echo e($course->price); ?> جنيه
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success">مجاني</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="fas fa-graduation-cap fa-4x text-muted mb-4"></i>
                        <h3 class="h4 text-muted">لا توجد دورات في هذا التصنيف</h3>
                        <p class="text-muted">سيتم إضافة دورات جديدة قريباً</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($courses->hasPages()): ?>
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($courses->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    <style>
        .hover-card {
            transition: all 0.3s ease;
        }

        .hover-card:hover {
            transform: translateY(-5px);
        }

        .badge {
            font-weight: 500;
        }

        /* Custom Pagination Styles */
        .pagination {
            gap: 0.5rem;
        }

        .page-link {
            border-radius: 50%;
            border: none;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--bs-primary);
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .page-item.active .page-link {
            background-color: var(--bs-primary);
        }

        .page-link:hover {
            background-color: var(--bs-primary-bg-subtle);
            color: var(--bs-primary);
            transform: scale(1.1);
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/Archive/resources/views/categories/show.blade.php ENDPATH**/ ?>