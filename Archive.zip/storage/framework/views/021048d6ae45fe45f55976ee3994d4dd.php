<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-5">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="h3 mb-0">دوراتي المسجلة</h2>
                    <div class="d-flex gap-2">
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                ترتيب حسب
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item <?php echo e(request('sort') == 'latest' ? 'active' : ''); ?>" href="?sort=latest">الأحدث</a></li>
                                <li><a class="dropdown-item <?php echo e(request('sort') == 'oldest' ? 'active' : ''); ?>" href="?sort=oldest">الأقدم</a></li>
                                <li><a class="dropdown-item <?php echo e(request('sort') == 'title' ? 'active' : ''); ?>" href="?sort=title">العنوان</a></li>
                            </ul>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                التصفية
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item <?php echo e(!request('filter') ? 'active' : ''); ?>" href="<?php echo e(request()->url()); ?>">الكل</a></li>
                                <li><a class="dropdown-item <?php echo e(request('filter') == 'in-progress' ? 'active' : ''); ?>" href="?filter=in-progress">قيد التقدم</a></li>
                                <li><a class="dropdown-item <?php echo e(request('filter') == 'completed' ? 'active' : ''); ?>" href="?filter=completed">مكتملة</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if($enrolledCourses->isEmpty()): ?>
                    <div class="text-center py-5">
                        <img src="<?php echo e(asset('images/empty-courses.svg')); ?>" alt="لا توجد دورات" class="img-fluid mb-4" style="max-width: 200px;">
                        <h3 class="h4 mb-3">لم تسجل في أي دورة بعد</h3>
                        <p class="text-muted mb-4">اكتشف دوراتنا المتنوعة وابدأ رحلة التعلم الخاصة بك</p>
                        <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary">
                            <i class="fas fa-search me-2"></i>استكشف الدورات
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php $__currentLoopData = $enrolledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="position-relative">
                                        <img src="<?php echo e(Storage::url($enrollment->course->image)); ?>" 
                                             class="card-img-top" 
                                             alt="<?php echo e($enrollment->course->title); ?>"
                                             style="height: 200px; object-fit: cover;">
                                        
                                        <?php if($enrollment->completed_at): ?>
                                            <div class="position-absolute top-0 end-0 m-2">
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check-circle me-1"></i>مكتمل
                                                </span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="card-body">
                                        <h5 class="card-title mb-3">
                                            <a href="<?php echo e(route('courses.learn', $enrollment->course)); ?>" class="text-decoration-none text-dark">
                                                <?php echo e($enrollment->course->title); ?>

                                            </a>
                                        </h5>
                                        
                                        <div class="d-flex align-items-center mb-3">
                                            <img src="<?php echo e(Storage::url($enrollment->course->instructor->avatar)); ?>" 
                                                 class="rounded-circle me-2" 
                                                 alt="<?php echo e($enrollment->course->instructor->name); ?>"
                                                 width="30" height="30">
                                            <span class="text-muted"><?php echo e($enrollment->course->instructor->name); ?></span>
                                        </div>

                                        <div class="progress mb-3" style="height: 8px;">
                                            <?php
                                                $progress = $enrollment->progress ?? 0;
                                            ?>
                                            <div class="progress-bar bg-primary" 
                                                 role="progressbar" 
                                                 style="width: <?php echo e($progress); ?>%"
                                                 aria-valuenow="<?php echo e($progress); ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100">
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-muted"><?php echo e($progress); ?>% مكتمل</span>
                                            <a href="<?php echo e(route('courses.learn', $enrollment->course)); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-play me-1"></i>متابعة التعلم
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        <?php echo e($enrolledCourses->links('vendor.pagination.custom')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/my-laravel-app/resources/views/user/enrolled-courses.blade.php ENDPATH**/ ?>