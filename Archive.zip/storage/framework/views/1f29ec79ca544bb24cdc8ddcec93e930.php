<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <div class="row align-items-center">
                            <div class="col">
                                <h5 class="mb-0">الكورسات المعتمدة</h5>
                                <p class="text-muted mb-0 small">عرض جميع الكورسات التي تم قبول طلبات الاشتراك فيها</p>
                            </div>
                            <div class="col-auto">
                                <div class="badge bg-success p-2">
                                    <div class="text-center">
                                        <div class="h6 mb-0">إجمالي الإيرادات</div>
                                        <div class="h4 mb-0"><?php echo e(number_format($totalRevenue, 2)); ?> ج.م</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-0">
                        <?php if($approvedCourses->isEmpty()): ?>
                            <div class="text-center py-5">
                                <img src="<?php echo e(asset('images/general/no-results.svg')); ?>" alt="لا توجد كورسات" class="img-fluid mb-4" style="max-width: 200px;">
                                <h3 class="h4 mb-3">لا توجد كورسات معتمدة حالياً</h3>
                                <p class="text-muted">ستظهر هنا الكورسات التي تم قبول طلبات الاشتراك فيها</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover mb-0 align-middle">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="border-0">#</th>
                                            <th class="border-0">الكورس</th>
                                            <th class="border-0">المدرب</th>
                                            <th class="border-0">السعر</th>
                                            <th class="border-0">عدد المشتركين</th>
                                            <th class="border-0">إجمالي الإيرادات</th>
                                            <th class="border-0">تفاصيل</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $approvedCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td style="min-width: 250px;">
                                                    <div class="d-flex align-items-center">
                                                        <?php if($course->image): ?>
                                                            <img src="<?php echo e(Storage::url($course->image)); ?>" 
                                                                 alt="<?php echo e($course->title); ?>" 
                                                                 class="rounded me-3"
                                                                 style="width: 48px; height: 48px; object-fit: cover;">
                                                        <?php else: ?>
                                                            <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center" 
                                                                 style="width: 48px; height: 48px;">
                                                                <i class="fas fa-graduation-cap text-muted"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div>
                                                            <h6 class="mb-1"><?php echo e($course->title); ?></h6>
                                                            <div class="small text-muted">
                                                                <i class="fas fa-layer-group me-1"></i>
                                                                <?php echo e($course->category->name ?? 'بدون تصنيف'); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <?php if($course->instructor && $course->instructor->avatar): ?>
                                                            <img src="<?php echo e(Storage::url($course->instructor->avatar)); ?>" 
                                                                 alt="<?php echo e($course->instructor->name); ?>"
                                                                 class="rounded-circle me-2"
                                                                 style="width: 32px; height: 32px; object-fit: cover;">
                                                        <?php else: ?>
                                                            <div class="bg-light rounded-circle me-2 d-flex align-items-center justify-content-center" 
                                                                 style="width: 32px; height: 32px;">
                                                                <i class="fas fa-user text-muted"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                        <span><?php echo e($course->instructor->name ?? 'غير محدد'); ?></span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="badge bg-success"><?php echo e(number_format($course->price, 2)); ?> ج.م</span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-primary"><?php echo e($course->total_enrollments); ?></span>
                                                </td>
                                                <td>
                                                    <div class="fw-bold text-success">
                                                        <?php echo e(number_format($course->total_revenue ?? ($course->price * $course->total_enrollments), 2)); ?> ج.م
                                                    </div>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.courses.show', $course)); ?>" 
                                                       class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-eye me-1"></i>
                                                        عرض التفاصيل
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="bg-light p-3 border-top">
                                <div class="row text-center">
                                    <div class="col-md-6 mb-3 mb-md-0">
                                        <h6 class="mb-1">إجمالي المشتركين</h6>
                                        <div class="h4 mb-0 text-primary"><?php echo e($totalEnrollments); ?></div>
                                    </div>
                                    <div class="col-md-6">
                                        <h6 class="mb-1">إجمالي الإيرادات</h6>
                                        <div class="h4 mb-0 text-success"><?php echo e(number_format($totalRevenue, 2)); ?> ج.م</div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/my-laravel-app/resources/views/admin/approved-courses/index.blade.php ENDPATH**/ ?>