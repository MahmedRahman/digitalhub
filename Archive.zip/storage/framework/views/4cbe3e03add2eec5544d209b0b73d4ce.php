<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .avatar {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 600;
        }
        .avatar-sm {
            width: 32px;
            height: 32px;
            font-size: 12px;
        }
        .table > :not(caption) > * > * {
            padding: 1rem;
        }
        .table tbody tr:hover {
            background-color: rgba(0,0,0,.02);
        }
    </style>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0 text-dark">طلبات الاشتراك في الدورات</h5>
                            <p class="text-muted mb-0 small">إدارة طلبات اشتراك المستخدمين في الدورات التدريبية</p>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <div class="dropdown">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-filter me-1"></i>تصفية حسب الحالة
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item <?php echo e(request('status') == 'all' ? 'active' : ''); ?>" href="<?php echo e(request()->fullUrlWithQuery(['status' => 'all'])); ?>">الكل</a></li>
                                    <li><a class="dropdown-item <?php echo e(request('status') == 'pending' ? 'active' : ''); ?>" href="<?php echo e(request()->fullUrlWithQuery(['status' => 'pending'])); ?>">قيد الانتظار</a></li>
                                    <li><a class="dropdown-item <?php echo e(request('status') == 'approved' ? 'active' : ''); ?>" href="<?php echo e(request()->fullUrlWithQuery(['status' => 'approved'])); ?>">مقبول</a></li>
                                    <li><a class="dropdown-item <?php echo e(request('status') == 'rejected' ? 'active' : ''); ?>" href="<?php echo e(request()->fullUrlWithQuery(['status' => 'rejected'])); ?>">مرفوض</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-0">
                        <?php if($enrollments->isEmpty()): ?>
                            <div class="text-center py-5">
                                <img src="<?php echo e(asset('images/general/no-results.svg')); ?>" alt="لا توجد طلبات" class="img-fluid mb-4" style="max-width: 200px;">
                                <h3 class="h4 mb-3">لا توجد طلبات اشتراك حالياً</h3>
                                <p class="text-muted">ستظهر هنا طلبات الاشتراك في الدورات عندما يقوم المستخدمون بالتسجيل</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover mb-0 align-middle">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="border-0">#</th>
                                            <th class="border-0">المستخدم</th>
                                            <th class="border-0">الدورة</th>
                                            <th class="border-0">تاريخ الطلب</th>
                                            <th class="border-0">الحالة</th>
                                            <th class="border-0">الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td style="min-width: 250px;">
                                                    <div class="d-flex align-items-center">
                                                        <div class="flex-shrink-0">
                                                            <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                                                <?php echo e(strtoupper(substr($enrollment->user->name, 0, 2))); ?>

                                                            </div>
                                                        </div>
                                                        <div class="ms-3">
                                                            <h6 class="mb-1"><?php echo e($enrollment->user->name); ?></h6>
                                                            <div class="d-flex flex-column text-muted small">
                                                                <span><i class="fas fa-envelope me-1"></i><?php echo e($enrollment->user->email); ?></span>
                                                                <?php if($enrollment->user->phone): ?>
                                                                    <span><i class="fas fa-phone me-1"></i><?php echo e($enrollment->user->phone); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td style="min-width: 200px;">
                                                    <div class="d-flex flex-column">
                                                        <a href="<?php echo e(route('courses.show', $enrollment->course)); ?>" class="text-decoration-none fw-medium mb-1">
                                                            <?php echo e($enrollment->course->title); ?>

                                                        </a>
                                                        <span class="text-muted small">
                                                            <i class="fas fa-tag me-1"></i><?php echo e($enrollment->course->price); ?> ج.م
                                                        </span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="small">
                                                        <i class="fas fa-calendar me-1"></i>
                                                        <?php if($enrollment->enrolled_at): ?>
                                                            <?php echo e(\Carbon\Carbon::parse($enrollment->enrolled_at)->format('Y/m/d')); ?>

                                                            <br>
                                                            <span class="text-muted">
                                                                <i class="fas fa-clock me-1"></i>
                                                                <?php echo e(\Carbon\Carbon::parse($enrollment->enrolled_at)->format('H:i')); ?>

                                                            </span>
                                                        <?php else: ?>
                                                            <?php echo e(\Carbon\Carbon::parse($enrollment->created_at)->format('Y/m/d')); ?>

                                                            <br>
                                                            <span class="text-muted">
                                                                <i class="fas fa-clock me-1"></i>
                                                                <?php echo e(\Carbon\Carbon::parse($enrollment->created_at)->format('H:i')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php if($enrollment->status === 'pending'): ?>
                                                        <span class="badge bg-warning">قيد الانتظار</span>
                                                    <?php elseif($enrollment->status === 'approved'): ?>
                                                        <span class="badge bg-success">مقبول</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">مرفوض</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($enrollment->status === 'pending'): ?>
                                                        <form action="<?php echo e(route('admin.enrollments.approve', $enrollment)); ?>" method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-sm btn-success">
                                                                <i class="fas fa-check me-1"></i>قبول
                                                            </button>
                                                        </form>

                                                        <button type="button" 
                                                                class="btn btn-sm btn-danger" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#rejectModal<?php echo e($enrollment->id); ?>">
                                                            <i class="fas fa-times me-1"></i>رفض
                                                        </button>

                                                        <!-- Reject Modal -->
                                                        <div class="modal fade" id="rejectModal<?php echo e($enrollment->id); ?>" tabindex="-1">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <form action="<?php echo e(route('admin.enrollments.reject', $enrollment)); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('PUT'); ?>
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">رفض طلب الاشتراك</h5>
                                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="mb-3">
                                                                                <label class="form-label">سبب الرفض</label>
                                                                                <textarea name="notes" class="form-control" rows="3" required></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                                            <button type="submit" class="btn btn-danger">تأكيد الرفض</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <button type="button" class="btn btn-sm btn-secondary" disabled>تم الإجراء</button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-flex justify-content-center border-top p-3">
                                <?php echo e($enrollments->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Desktop/course/my-laravel-app/resources/views/admin/enrollments/index.blade.php ENDPATH**/ ?>